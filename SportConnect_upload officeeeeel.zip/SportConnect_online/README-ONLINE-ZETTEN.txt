SPORTCONNECT ONLINE ZETTEN

Deze versie is aangepast voor Render (website) en Neon (online PostgreSQL-database).
De website gebruikt PostgreSQL zodra DATABASE_URL is ingesteld. Zonder die instelling gebruikt de website lokaal SQLite.

STAP 1. GITHUB
1. Maak een account op https://github.com als je dat nog niet hebt.
2. Maak een nieuwe repository met de naam sportconnect.
3. Kies Public of Private en maak de repository aan.
4. Pak deze ZIP helemaal uit.
5. Upload de bestanden en mappen uit de map SportConnect_online naar de hoofdmap van je GitHub-repository.
6. Controleer dat render.yaml direct in de hoofdmap van de repository staat.
7. Upload GEEN bestaande .sqlite3 databasebestanden of echte persoonsgegevens.

STAP 2. NEON DATABASE
1. Ga naar https://neon.com en maak een gratis account aan.
2. Maak een nieuw PostgreSQL-project aan, bijvoorbeeld sportconnect.
3. Open Connect en kopieer de connection string voor Python/psycopg.
4. Bewaar deze connection string privé. Zet hem nooit in GitHub of in je code.

STAP 3. RENDER WEBSITE
1. Ga naar https://render.com en maak een account aan.
2. Kies New > Blueprint.
3. Verbind je GitHub-account en klik Connect bij de repository sportconnect.
4. Render leest render.yaml en toont de instellingen voor de website.
5. Bij DATABASE_URL plak je de Neon connection string.
6. Klik op Deploy Blueprint.
7. Wacht tot de webservice de status Live heeft.
8. Open de service en kopieer de onrender.com URL. Dat is de openbare link voor je docent.

BELANGRIJK
- De website is publiek toegankelijk. Gebruik uitsluitend testgegevens. Zet geen echte privégegevens van klasgenoten online.
- Neon Free heeft een gebruikslimiet. De data blijft in de database staan wanneer de compute in slaapstand gaat. Controleer het actuele gebruik in Neon.
- Render Free zet de website na 15 minuten zonder bezoek in slaapstand. Het eerste bezoek daarna kan even laden.
- De Database-pagina is uit deze openbare versie verwijderd. Zo zijn e-mailadressen en accountgegevens niet publiek zichtbaar.
- De voorbeeldactiviteiten zijn demo's. Ze zijn geen echte georganiseerde sportbijeenkomsten.
- Je kunt later aanpassingen uploaden naar GitHub. Render publiceert die automatisch opnieuw.
